package com.auravpn.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
